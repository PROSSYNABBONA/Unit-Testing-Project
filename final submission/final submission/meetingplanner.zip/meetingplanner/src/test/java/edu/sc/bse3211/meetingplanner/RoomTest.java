package edu.sc.bse3211.meetingplanner;

import static org.junit.Assert.*;
import org.junit.Test;

public class RoomTest {
    
    @Test
    public void testDefaultConstructor() {
        Room room = new Room();
        assertNotNull(room);
        assertEquals("", room.getID());
    }
    
    @Test
    public void testParameterizedConstructor() {
        String roomID = "Room1";
        Room room = new Room(roomID);
        assertNotNull(room);
        assertEquals(roomID, room.getID());
    }
    
      //Testing adding a meeting
    @Test
    public void testAddMeeting() {
        Room room = new Room("Room1");
        Meeting meeting = new Meeting(4, 27, 9, 10);
        
        try {
            room.addMeeting(meeting);
            // making sure the meeting was added successfully
            assertTrue(room.isBusy(4, 27, 9, 10));
        } catch (TimeConflictException e) {
            fail("Unexpected TimeConflictException: " + e.getMessage());
        }
    }


    //Testing the Printing of the agenda for a month.
    @Test
    public void testPrintAgendaByMonth() {
        Room room = new Room();
        assertNotNull(room.printAgenda(3));
    }


    //Testing the Printing of the agenda for a month with day.
    @Test
    public void testPrintAgendaByMonthAndDay() {
        Room room = new Room();
        assertNotNull(room.printAgenda(3, 27));
    }


    //Testing if a meeting is scheduled during a timeframe..
    @Test
    public void testIsBusyWhenBusy() {
        Room room = new Room("Room1");
        Meeting meeting = new Meeting(3, 27, 9, 10);
        try {
            room.addMeeting(meeting);
            assertTrue(room.isBusy(3, 27, 9, 10));
            // assertFalse(room.isBusy(3, 27, 10, 11));
        } catch (TimeConflictException e) {
            fail("Unexpected TimeConflictException: " + e.getMessage());
        }
    }

    @Test
    public void testIsBusyWhenNotBusy() {
        Room room = new Room("Room1");
        try {
            assertFalse(room.isBusy(3, 27, 10, 11));
        } catch (TimeConflictException e) {
            fail("Unexpected TimeConflictException: " + e.getMessage());
        }
    }


    //Test to Gets a particular meeting.
    @Test
    public void testGetMeeting() {
        Room room = new Room("Room1");
        Meeting meeting = new Meeting(3, 27);
        try {
            room.addMeeting(meeting);
            assertEquals(meeting, room.getMeeting(3, 27, 0));
            
        }
         catch (TimeConflictException e) {
            fail("Unexpected TimeConflictException: " + e.getMessage());
        }
    }


    //Test to remove Meeting
    @Test
    public void testRemoveMeeting() {
        Room room = new Room("Room1");
        Meeting meeting = new Meeting(3, 27);
        try {
            room.addMeeting(meeting);
            room.removeMeeting(3, 27, 0);
            assertFalse(room.isBusy(3, 27, 9, 10));
        } catch (TimeConflictException e) {
            fail("Unexpected TimeConflictException: " + e.getMessage());
        }
    }
    
}